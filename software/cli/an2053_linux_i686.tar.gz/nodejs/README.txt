Ansync AN2053 Control Software
http://ansync.com
Support: support@ansync.com

The AN2053 Control Software is a NodeJS-based application to control your
AN2053.  The application supports multiple devices on a single machine, and
allows users to control the AN2053 from any machine on the network.

================================================================================
PREREQUISITES
================================================================================

Your AN2053 may require new firmware to work correctly with the control
software.  Use the updater script in the util directory to ensure your device
has the latest firmware.

================================================================================
USAGE
================================================================================

To start the software, run:
    # node app.js
from this directory, as root.

To add your AN2053 to the control software, edit devices.json:
    "motor1" : {
        "model" : "AN2053",
        "serial": <serial>
    }
Replace <serial> with the serial number of your AN2053.  The serial number is on
the back label, after "2053-".  The serial number can also be found with the
manage utility in the util directory.

Devices.json comes preloaded with information for 2 motor controllers.
Additional devices may be added as needed:
    <alias> : {
        "model" : <model>,
        "serial": <serial>
    }
Then edit views/index.jade to add a widget for your device:
    div.an_channel_slider(data-channel="1", data-alias=<alias>, data-min=-100, data-max=100)

You can also add widgets without adding your device to devices.json:
    div.an_channel_slider(data-channel="1", data-serial=<serial>, data-min=-100, data-max=100)
        or
    div.an_channel_slider(data-channel="1", data-model="AN2053", data-min=-100, data-max=100)
