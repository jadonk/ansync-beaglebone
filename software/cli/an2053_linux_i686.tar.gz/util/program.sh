#!/bin/bash

SERIAL=""
NEWSERIAL=""
MODEL="AN2053"
FX2=-1

if [[ $EUID -ne 0 ]]
then
    echo "This script must be run as root." 2>&1
    exit
fi

while getopts ":s:h" opt; do
  case $opt in
    s)
      NEWSERIAL=$OPTARG
      ;;
    h)
      echo "Usage: $0 [-s <serial>]"
      echo -e "\t-s <serial>\tSerial number to program on device (optional)"
      ;;
    \?)
      echo "Invalid option: -$OPTARG" >&2
      echo "Usage: $0 [-s <serial>]"
      echo -e "\t-s <serial>\tSerial number to program on device (optional)"
      exit 1
      ;;
    :)
      echo "Option -$OPTARG requires an argument." >&2
      echo "Usage: $0 [-s <serial>]"
      echo -e "\t-s <serial>\tSerial number to program on device (optional)"
      exit 1
      ;;
  esac
done

# Attempt to discover what kind of device we're talking to
echo -n "Discovering device . . . "
SERIAL=$(./manage getinfo | grep 'serial number is' | sed 's/.*serial number is\s*\([0-9]*\)$/\1/')
if [ -z "$SERIAL" ]
then
    # Attempt to read serial number failed; try old version
    SERIAL=$(./manage -t an getinfo | grep 'serial number is' | sed 's/.*serial number is\s*\([0-9]*\)$/\1/')
    if [ -z "$SERIAL" ]
    then
        echo "failed."
        echo "Unable to communicate with device."
        exit
    else
        FX2=0
        echo "got AN2053AN."
        sleep 1
    fi
else
    FX2=1
    echo "got AN2053."
    sleep 1
fi

echo "Programming firmware . . . "
if [ "$FX2" -eq "1" ]
then
    ./manage programchip -I ./top.hex
    sleep 3
    ./manage programeeprom -I ./top.hex
elif [ "$FX2" -eq "0" ]
then
    ./manage -t an programeeprom -I ./top_an.hex
else
    echo "Unknown device type."
    exit
fi
echo "Unplug device and plug back in.  Press enter when done."
read
echo "Waiting for device to enumerate . . . "

for i in {1..10}
do
    if lsusb | grep -q "165f"
    then
        echo "Success.  Programming identity."

        if [ -n "$NEWSERIAL" ]
        then
            SERIAL="$NEWSERIAL"
        fi

        if [ "$FX2" -eq "0" ]
        then
            MODEL="AN2053AN"
        fi

        echo Programming serial $SERIAL and model $MODEL
        sleep 1
        if [ "$FX2" -eq "0" ]
        then
            while [ ${#SERIAL} -lt 6 ] # Need to add leading 0 for AN2053AN; first digit will be truncated
            do
                SERIAL="0$SERIAL"
            done
            ./manage -t an setserial -n $SERIAL
        else
            ./manage setserial -n $SERIAL
        fi

        if [ "$FX2" -eq "1" ]
        then
            ./ansetPrdcli $MODEL
        fi

        exit
    fi

    sleep 1
done

# Timed out waiting for device.
echo Programming failed.
exit

